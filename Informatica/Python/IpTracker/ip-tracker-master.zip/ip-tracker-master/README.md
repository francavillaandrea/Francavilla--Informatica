# Gods-eye

<head><meta name="google-site-verification" content="nndzEDrAeFU6uxmF5jOvELOanzHA0QT0h7zJoxRGxzg" /></head>

# commands for installing gods-eye:
```
  git clone https://github.com/dellano54/Gods-eye.git
  cd Gods-eye/
  sudo chmod +x install.sh
  sudo ./install.sh
  ```
# Easy installation
```
wget https://github.com/dellano54/Scripts-for-repositories/raw/master/Gods-eye.sh && sudo chmod +x Gods-eye.sh && sudo ./Gods-eye.sh
  ```

  I am not responsible for any damage caused by this tool.
  This is only for educational purpose.
  
<h3>screenshots</h3>
  
![we are having an error in displaying image.we will fix it soon.](https://raw.githubusercontent.com/dellano54/Gods-eye/master/screenshot/screenshot.png)
![we are having an error in displaying image.we will fix it soon.](https://raw.githubusercontent.com/dellano54/Gods-eye/master/screenshot/Screenshot%202020-06-12%2005%3A54%3A53.png)

