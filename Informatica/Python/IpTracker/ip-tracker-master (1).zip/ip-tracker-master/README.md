# Ip-Tracker by HackerSM9
## Disclaimer: 
> You shall not misuse the information to gain unauthorised access. I will not be Responsible for Anything, Use at Your Own Risk..⚠️

> **_Note_**:  This not for **illegal** usage..⚠️
### Requirements:
- Python3
- PHP
### Installation & Running the Tool
```
cd
git clone https://github.com/HackerSM9/ip-tracker
cd ip-tracker
bash setup.sh
```
## Screenshots
<img src="https://github.com/HackerSM9/ip-tracker/blob/main/.src/main-menu.jpg">
<img src="https://github.com/HackerSM9/ip-tracker/blob/main/.src/Your-ip.jpg">
<img src="https://github.com/HackerSM9/ip-tracker/blob/main/.src/Tracked-ip.jpg">
