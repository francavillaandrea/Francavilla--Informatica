﻿namespace Battaglia_Navale
{
    partial class FrmMain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGriglia1 = new System.Windows.Forms.DataGridView();
            this.dgvGriglia2 = new System.Windows.Forms.DataGridView();
            this.lblGiocatore1 = new System.Windows.Forms.Label();
            this.lblGiocatore2 = new System.Windows.Forms.Label();
            this.lblTurno = new System.Windows.Forms.Label();
            this.txbRiga = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSpara = new System.Windows.Forms.Button();
            this.btnGioca = new System.Windows.Forms.Button();
            this.gpb1 = new System.Windows.Forms.GroupBox();
            this.lblCnt1 = new System.Windows.Forms.Label();
            this.lblCnt2 = new System.Windows.Forms.Label();
            this.txbColonna = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGriglia1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGriglia2)).BeginInit();
            this.gpb1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGriglia1
            // 
            this.dgvGriglia1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvGriglia1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvGriglia1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGriglia1.EnableHeadersVisualStyles = false;
            this.dgvGriglia1.Location = new System.Drawing.Point(32, 85);
            this.dgvGriglia1.Name = "dgvGriglia1";
            this.dgvGriglia1.RowHeadersWidth = 51;
            this.dgvGriglia1.RowTemplate.Height = 24;
            this.dgvGriglia1.Size = new System.Drawing.Size(417, 385);
            this.dgvGriglia1.TabIndex = 0;
            // 
            // dgvGriglia2
            // 
            this.dgvGriglia2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvGriglia2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvGriglia2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGriglia2.EnableHeadersVisualStyles = false;
            this.dgvGriglia2.Location = new System.Drawing.Point(909, 85);
            this.dgvGriglia2.Name = "dgvGriglia2";
            this.dgvGriglia2.RowHeadersWidth = 51;
            this.dgvGriglia2.RowTemplate.Height = 24;
            this.dgvGriglia2.Size = new System.Drawing.Size(417, 385);
            this.dgvGriglia2.TabIndex = 1;
            // 
            // lblGiocatore1
            // 
            this.lblGiocatore1.AutoSize = true;
            this.lblGiocatore1.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiocatore1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblGiocatore1.Location = new System.Drawing.Point(1046, 9);
            this.lblGiocatore1.Name = "lblGiocatore1";
            this.lblGiocatore1.Size = new System.Drawing.Size(180, 34);
            this.lblGiocatore1.TabIndex = 2;
            this.lblGiocatore1.Text = "Giocatore 1";
            // 
            // lblGiocatore2
            // 
            this.lblGiocatore2.AutoSize = true;
            this.lblGiocatore2.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiocatore2.ForeColor = System.Drawing.Color.Red;
            this.lblGiocatore2.Location = new System.Drawing.Point(94, 9);
            this.lblGiocatore2.Name = "lblGiocatore2";
            this.lblGiocatore2.Size = new System.Drawing.Size(180, 34);
            this.lblGiocatore2.TabIndex = 3;
            this.lblGiocatore2.Text = "Giocatore 2";
            // 
            // lblTurno
            // 
            this.lblTurno.AutoSize = true;
            this.lblTurno.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTurno.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblTurno.Location = new System.Drawing.Point(77, 18);
            this.lblTurno.Name = "lblTurno";
            this.lblTurno.Size = new System.Drawing.Size(0, 34);
            this.lblTurno.TabIndex = 4;
            // 
            // txbRiga
            // 
            this.txbRiga.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRiga.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txbRiga.Location = new System.Drawing.Point(31, 233);
            this.txbRiga.Name = "txbRiga";
            this.txbRiga.Size = new System.Drawing.Size(138, 40);
            this.txbRiga.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label3.Location = new System.Drawing.Point(16, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(362, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Inserisci la cella dove vuoi sparare";
            // 
            // btnSpara
            // 
            this.btnSpara.BackColor = System.Drawing.Color.Red;
            this.btnSpara.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpara.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSpara.Location = new System.Drawing.Point(134, 320);
            this.btnSpara.Name = "btnSpara";
            this.btnSpara.Size = new System.Drawing.Size(137, 59);
            this.btnSpara.TabIndex = 7;
            this.btnSpara.Text = "SPARA";
            this.btnSpara.UseVisualStyleBackColor = false;
            this.btnSpara.Click += new System.EventHandler(this.btnSpara_Click);
            // 
            // btnGioca
            // 
            this.btnGioca.BackColor = System.Drawing.Color.Aquamarine;
            this.btnGioca.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGioca.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnGioca.Location = new System.Drawing.Point(526, 522);
            this.btnGioca.Name = "btnGioca";
            this.btnGioca.Size = new System.Drawing.Size(276, 78);
            this.btnGioca.TabIndex = 8;
            this.btnGioca.Text = "GIOCA";
            this.btnGioca.UseVisualStyleBackColor = false;
            this.btnGioca.Click += new System.EventHandler(this.btnGioca_Click);
            // 
            // gpb1
            // 
            this.gpb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gpb1.Controls.Add(this.label2);
            this.gpb1.Controls.Add(this.label1);
            this.gpb1.Controls.Add(this.txbColonna);
            this.gpb1.Controls.Add(this.btnSpara);
            this.gpb1.Controls.Add(this.txbRiga);
            this.gpb1.Controls.Add(this.lblTurno);
            this.gpb1.Controls.Add(this.label3);
            this.gpb1.Location = new System.Drawing.Point(455, 85);
            this.gpb1.Name = "gpb1";
            this.gpb1.Size = new System.Drawing.Size(400, 385);
            this.gpb1.TabIndex = 9;
            this.gpb1.TabStop = false;
            // 
            // lblCnt1
            // 
            this.lblCnt1.AutoSize = true;
            this.lblCnt1.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCnt1.ForeColor = System.Drawing.Color.Red;
            this.lblCnt1.Location = new System.Drawing.Point(94, 566);
            this.lblCnt1.Name = "lblCnt1";
            this.lblCnt1.Size = new System.Drawing.Size(220, 34);
            this.lblCnt1.TabIndex = 10;
            this.lblCnt1.Text = "Navi rimaste: ";
            // 
            // lblCnt2
            // 
            this.lblCnt2.AutoSize = true;
            this.lblCnt2.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCnt2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblCnt2.Location = new System.Drawing.Point(1008, 566);
            this.lblCnt2.Name = "lblCnt2";
            this.lblCnt2.Size = new System.Drawing.Size(227, 34);
            this.lblCnt2.TabIndex = 11;
            this.lblCnt2.Text = "Navi Rimaste: ";
            // 
            // txbColonna
            // 
            this.txbColonna.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbColonna.ForeColor = System.Drawing.SystemColors.MenuText;
            this.txbColonna.Location = new System.Drawing.Point(256, 233);
            this.txbColonna.Name = "txbColonna";
            this.txbColonna.Size = new System.Drawing.Size(138, 40);
            this.txbColonna.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(66, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Riga";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.Location = new System.Drawing.Point(265, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Colonna";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1338, 652);
            this.Controls.Add(this.lblCnt2);
            this.Controls.Add(this.lblCnt1);
            this.Controls.Add(this.gpb1);
            this.Controls.Add(this.btnGioca);
            this.Controls.Add(this.lblGiocatore2);
            this.Controls.Add(this.lblGiocatore1);
            this.Controls.Add(this.dgvGriglia2);
            this.Controls.Add(this.dgvGriglia1);
            this.Name = "FrmMain";
            this.Text = "Battaglia Navale";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGriglia1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGriglia2)).EndInit();
            this.gpb1.ResumeLayout(false);
            this.gpb1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGriglia1;
        private System.Windows.Forms.DataGridView dgvGriglia2;
        private System.Windows.Forms.Label lblGiocatore1;
        private System.Windows.Forms.Label lblGiocatore2;
        private System.Windows.Forms.Label lblTurno;
        private System.Windows.Forms.TextBox txbRiga;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSpara;
        private System.Windows.Forms.Button btnGioca;
        private System.Windows.Forms.GroupBox gpb1;
        private System.Windows.Forms.Label lblCnt1;
        private System.Windows.Forms.Label lblCnt2;
        private System.Windows.Forms.TextBox txbColonna;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

