﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Battaglia_Navale
{
    public partial class FrmMain: Form
    {
        static Random rnd = new Random();

        const int ROWS = 10;
        const int COLUMNS = 10;

        int cntNavi1 = 2, cntNavi2 = 2;
        bool turno = true;

        int[,] griglia1 = new int[ROWS, COLUMNS];
        int[,] griglia2 = new int[ROWS, COLUMNS];

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            gpb1.Visible = false;
            lblCnt1.Visible = false;
            lblCnt2.Visible = false;
            lblGiocatore1.Visible = false;
            lblGiocatore2.Visible = false;
            btnGioca.Enabled = true;
            btnSpara.Enabled = false;
        }

        private void btnGioca_Click(object sender, EventArgs e)
        {
            
            settaDGV();
            impostaGriglie(cntNavi1);
            btnGioca.Enabled = false;
            btnSpara.Enabled = true;
            gpb1.Visible = true;
            lblCnt1.Visible = true;
            lblCnt2.Visible = true;
            lblGiocatore1.Visible = true;
            lblGiocatore2.Visible = true;
            dgvGriglia1.Visible = true;
            dgvGriglia2.Visible = true;

            lblTurno.Text = "Turno: Giocatore 1";
            lblTurno.ForeColor = Color.Blue;

            lblCnt1.Text = $"Navi rimaste: {cntNavi1}";
            lblCnt2.Text = $"Navi rimaste: {cntNavi2}";

        }
        private void btnSpara_Click(object sender, EventArgs e)
        {
            partita();
        }

        private void partita()
        {
            
            if(cntNavi1 != 0 && cntNavi2 != 0)
            {
                turno = !turno;

                if (turno)
                {
                    lblTurno.Text = "Turno: Giocatore 1";
                    lblTurno.ForeColor = Color.Blue;
                }
                else
                {
                    lblTurno.Text = "Turno: Giocatore 2";
                    lblTurno.ForeColor = Color.DarkRed;
                }

                lblCnt1.Text = $"Navi rimaste: {cntNavi1}";
                lblCnt2.Text = $"Navi rimaste: {cntNavi2}";

                int riga, colonna;

                if(int.TryParse(txbRiga.Text, out riga) && riga-1>=0 && riga-1<=9 && int.TryParse(txbColonna.Text, out colonna) && colonna - 1 >= 0 && colonna - 1 <= 9)
                {
                    if(turno)
                    {
                        if(griglia2[riga-1, colonna-1] == 1)
                        {
                            griglia2[riga-1, colonna-1] = 0;
                            visualizzaGriglie();
                            cntNavi2--;
                        }
                        else
                        {
                            MessageBox.Show("Cella Senza nave");
                        }
                        
                    }
                    else
                    {
                        if (griglia1[riga-1, colonna-1] == 1)
                        {
                            griglia1[riga-1, colonna-1] = 0;
                            visualizzaGriglie();
                            cntNavi1--;
                        }
                        else
                        {
                            MessageBox.Show("Cella Senza nave");
                        }
                    }

                    lblCnt1.Text = $"Navi rimaste: {cntNavi1}";
                    lblCnt2.Text = $"Navi rimaste: {cntNavi2}";

                    txbColonna.Text = "";
                    txbRiga.Text = "";
                }
                else
                {
                    MessageBox.Show("CELLA NON VALIDA, RIPROVA NEL PROSSIMO TURNO");
                }


                if (cntNavi2 == 0 || cntNavi1 == 0)
                {
                    if (cntNavi2 == 0)
                    {
                        MessageBox.Show("Ha vinto il Giocatore 2");
                    }
                    if (cntNavi1 == 0)
                    {
                        MessageBox.Show("Ha vinto il Giocatore 1");
                    }

                    gpb1.Visible = false;
                    lblCnt1.Visible = false;
                    lblCnt2.Visible = false;
                    lblGiocatore1.Visible = false;
                    lblGiocatore2.Visible = false;
                    btnGioca.Enabled = true;
                    btnSpara.Enabled = false;

                    griglia1 = new int[ROWS,COLUMNS];
                    griglia2 = new int[ROWS, COLUMNS];
                    dgvGriglia1.Visible = false;
                    dgvGriglia2.Visible = false;
                    cntNavi1 = 2;
                    cntNavi2 = 2;
                    turno = true;
                }
            }

        }

        private void impostaGriglie(int cntNavi1)
        {
            for (int i = 0; i < cntNavi1; i++)
            {
                int x = rnd.Next(0, 10);
                int y = rnd.Next(0, 10);
                griglia1[x, y] = 1;
                x = rnd.Next(0, 10);
                y = rnd.Next(0, 10);
                griglia2[x, y] = 1;
            }
            visualizzaGriglie();
            
        }

        private void visualizzaGriglie()
        {
            
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLUMNS; j++)
                {
                    dgvGriglia1.Rows[i].Cells[j].Style.BackColor = Color.White;
                    dgvGriglia1.Rows[i].Cells[j].Style.BackColor = Color.White;
                    if (griglia1[i, j] == 1)
                    {
                        dgvGriglia1.Rows[i].Cells[j].Style.BackColor = Color.Black;
                    }
                    else
                    {
                        dgvGriglia1.Rows[i].Cells[j].Style.BackColor = Color.Aqua;
                        dgvGriglia1.Rows[i].Cells[j].Style.ForeColor = Color.Aqua;
                    }
                    if (griglia2[i, j] == 1)
                    {
                        dgvGriglia2.Rows[i].Cells[j].Style.BackColor = Color.Black;
                    }
                    else
                    {
                        dgvGriglia2.Rows[i].Cells[j].Style.BackColor = Color.Aqua;
                        dgvGriglia2.Rows[i].Cells[j].Style.ForeColor = Color.Aqua;
                    }
                    dgvGriglia1.Rows[i].Cells[j].Value = griglia1[i, j].ToString();
                    dgvGriglia2.Rows[i].Cells[j].Value = griglia2[i, j].ToString();
                }
            }
        }

        private void settaDGV()
        {
            

            dgvGriglia1.RowCount = ROWS+1;
            dgvGriglia2.RowCount = ROWS+1;
            dgvGriglia1.ColumnCount = COLUMNS;
            dgvGriglia2.ColumnCount = COLUMNS;

            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLUMNS; j++)
                {
                    dgvGriglia1.Rows[i].Height = 20;
                    dgvGriglia2.Rows[i].Height = 20;

                    dgvGriglia1.Columns[j].Width = 20;
                    dgvGriglia2.Columns[j].Width = 20;
                }
            }

            dgvGriglia1.AllowUserToAddRows = false;
            dgvGriglia1.AllowUserToDeleteRows = false;
            dgvGriglia1.AllowUserToOrderColumns = false;
            dgvGriglia1.AllowUserToResizeRows = false;

            dgvGriglia2.AllowUserToAddRows = false;
            dgvGriglia2.AllowUserToDeleteRows = false;
            dgvGriglia2.AllowUserToOrderColumns = false;
            dgvGriglia2.AllowUserToResizeRows = false;

            for (int i = 0; i < ROWS; i++)
            {

                dgvGriglia1.Rows[i].HeaderCell.Value = $"{i+1}";
                dgvGriglia2.Rows[i].HeaderCell.Value = $"{i+1}";

                dgvGriglia1.Rows[i].HeaderCell.Style.BackColor = Color.Aquamarine;
                dgvGriglia2.Rows[i].HeaderCell.Style.BackColor = Color.Aquamarine;
            }

            for (int j = 0; j < COLUMNS; j++)
            {
                dgvGriglia1.Columns[j].HeaderText = $"{j+1}";
                dgvGriglia2.Columns[j].HeaderText = $"{j+1}";

                dgvGriglia1.Columns[j].HeaderCell.Style.BackColor = Color.Aquamarine;
                dgvGriglia2.Columns[j].HeaderCell.Style.BackColor = Color.Aquamarine;
            }


            dgvGriglia1.ClearSelection();
            dgvGriglia2.ClearSelection();

        }

      
    }
}
